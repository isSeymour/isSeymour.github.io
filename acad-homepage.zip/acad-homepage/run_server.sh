#!/usr/bin/env bash
bundle exec jekyll serve --livereload --port 4000
